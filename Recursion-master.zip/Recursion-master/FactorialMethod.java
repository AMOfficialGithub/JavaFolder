import java.util.Scanner;

public class FactorialMethod
{
public static void main(String[] args)
{
//Accepting user input
int number;
Scanner scan= new Scanner(System.in);
//User input. Does not have delimiter
System.out.println("Enter in a non-negative integer");
number=scan.nextInt();
System.out.println(number+" is "+factorial(number));
}
public static int factorial(int n)
{
if(n==0)
return 1;
else
//Returns 1. Multiplies 1 by the factorial method.
return n*factorial(n-1);
}
}
