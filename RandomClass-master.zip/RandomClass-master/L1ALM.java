import java.util.Scanner;
import java.util.Random;

public class L1ALM
{
public static void main(String[] args)
{
//Storage variables
    int i, j, k, suma;

    String l;

    char select;



//create Scanner object

    Scanner keyboard = new Scanner(System.in);



//create random object. The previous class name of random number generation class is different. The name of the class is based on mine.

    RandomALM num = new RandomALM();//Calling the associated class file.



//get two random numbers from random.java class defined

    i = num.random_num1();

    j = num.random_num2();



//make keyboard input

    System.out.print("Select + or -:  ");

    l = keyboard.nextLine();

    select=l.charAt(0);


//Delimiter initiated with the if statement.
//Also can be issued with the while statement.
    if(select == '+' )
	{

	       num.calculateadd();//built in Java method.



	       System.out.print(i + " + " + j + " = " );

	       suma = keyboard.nextInt();

	       num.compare(suma);

	}



    if(select == '-')

	{

	       num.calculateminus();



	       System.out.print(i + " - " + j + " = " );

	       suma = keyboard.nextInt();

	       num.compare(suma);

	}

}

}