import java.util.Random;

public class RandomALM
{
	//Private Storage Variables
    private int i;
    private int j;
    private int sum1;
    private int sum2;

    Random addme = new Random();

    public int random_num1()
    {
        int value = 0;
        if(i>=0&&i<=9)//initalized value of 0.
        {
            i=addme.nextInt(9)+1;//Becomes 10.
            value=i;
        }
        return value;
    }
    public int random_num2()
    {
        int value=0;

        if(j>=0&&j<=9)
        {
            j=addme.nextInt(9)+1;//Becomes 10
            value = j;
        }
        return value;
    }

    public int calculateadd() {
        sum1=i+j;
        return sum1;
    }

    public int calculateminus() {
        sum1=i-j;
        return sum1;
    }
//Compare is a built-in method from Java.
    public int compare(int suma)
    {
        if (sum1 == suma) {
            System.out.println("The numbers are same");
        }
        else
        {
        	System.out.println("The numbers are NOT same");
        }
        return 0;
    }
}