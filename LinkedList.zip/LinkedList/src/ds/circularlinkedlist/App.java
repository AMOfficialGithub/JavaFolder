package ds.circularlinkedlist;

public class App {
    CircularLinkedList mylist = new CircularLinkedList();
    mylist.insertFirst(100);
    mylist.insertFirst(50);
    mylist.insertFirst(90);
    mylist.insertLast(99999);
    
    mylist.displaylist();
}
