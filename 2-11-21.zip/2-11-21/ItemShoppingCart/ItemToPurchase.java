public class ItemToPurchase
{

/* Type code here. */
private String itemName;
private int itemPrice;
private int itemQuantity;

public ItemToPurchase()
{
   this.itemName = "none";
   this.itemPrice = 0;
   this.itemQuantity= 0;
}

public ItemToPurchase(String itemName, int itemPrice, int itemQuantity)
{
   this.itemName= itemName;
   this.itemPrice= itemPrice;
   this.itemQuantity= itemQuantity;
}

public void setName(String name)
{
   this.itemName= name;
}
public String getName()
{
   return itemName;
}

public void setPrice(int price)
{
   this. itemPrice= price;
}
public int getPrice()
{
   return itemPrice;
}

public void setQuantity(int quantity)
{
   this.itemQuantity=quantity;
}

public int getQuantity()
{

   return itemQuantity;
}


}