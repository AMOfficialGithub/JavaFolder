import java.util.Scanner;

public class ShoppingCartPrinter {

   public static void main(String[] args) {
      Scanner scnr = new Scanner(System.in);

      String price,price2;
      String quantity,quantity2;
      String name,name2;

      //Creation of two items
      ItemToPurchase item1 = new ItemToPurchase();
      ItemToPurchase item2 = new ItemToPurchase();

      //Item 1
      System.out.println("Item 1");
      System.out.println("Enter the item name:");
      name = scnr.nextLine();
      item1.setName(name);
      System.out.println("Enter the item price:");
      price =scnr.nextLine();
      item1.setPrice(Integer.parseInt(price));
      System.out.println("Enter the item quantity:");
      quantity = scnr.nextLine();
      item1.setQuantity(Integer.parseInt(quantity));


      System.out.println();

      //Item 2
      System.out.println("Item 2");
      System.out.println("Enter the item name:");
      name2=scnr.nextLine();
      item2.setName(name2);
      System.out.println("Enter the item price:");
      price2=scnr.nextLine();
      item2.setPrice(Integer.parseInt(price2));
      System.out.println("Enter the item quantity:");
      quantity2= scnr.nextLine();
      item2.setQuantity(Integer.parseInt(quantity2));


      //Mathmatical Equation cost
      int sum = item1.getQuantity() * item1.getPrice();
      int sum2 = item2.getQuantity() * item2.getPrice();

      //mathmatical question cost together
      int totalCost = sum+sum2;
      System.out.println();
      System.out.println("TOTAL COST");
      System.out.println(item1.getName()+" "+item1.getQuantity()+" "+"@"+" "+"$"+item1.getPrice()+" = "+"$"+sum);
      System.out.println(item2.getName()+" "+item2.getQuantity()+" "+"@"+" "+"$"+item2.getPrice()+" = "+"$"+sum2);
      System.out.println();
      System.out.println("Total: "+"$"+totalCost);

   }
}
