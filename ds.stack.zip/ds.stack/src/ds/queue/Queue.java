package ds.queue;


public class Queue {
    //maxSize maintains number of slots
    private int maxSize, front, rear, nItems; //index position for element in front, index position
    //at back of line. counter to maintain # of items in que
    private long[] queArray; //Slots to maintain the data
    
    public Queue(int size)
    {
        this.maxSize = size;
        this.queArray = new long[size];
        front = 0; //index position of first slot of array
        rear = -1; //no item in the array as the last item
        nItems = 0 ; //don't have elements in the array yet
    }
    public void insert(long j)
    {
        if(rear ==maxSize -1){
            rear = -1;
        }
        rear++;
        queArray[rear] = j;
        nItems ++;
    }
    //remove item from the front of queue
    public long remove()
    {
        long temp = queArray[front];
        front++;
        if(front == maxSize){
            front = 0; //set front back to the 0th index to utilize entire array
        }
        nItems--;
        return temp;
    }
    public long peakFront()
    {
        return queArray[front];
    }
    
    public boolean isEmpty(){
        return (nItems == 0);
    }
    
    public boolean isFull(){
        return (nItems == maxSize);
    }
    public void view(){
        System.out.print("[ ");
        for(int i = 0; i <queArray.length; i++)
        {
            System.out.print(queArray[i]+ " ");
        }
        System.out.println("] ");
    }
    
    
}
