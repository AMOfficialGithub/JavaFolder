import java.util.Scanner;

public class StringTooLongException
//The getMessage is part of the java.lang.Throwable library.
//Unreachable statement is caused by either a break, throw, or clause reserved word.
{
//Setting the maximum amount of number for String-Type
//The final reserved word must always have Capitalized Words and underscore seperating two names.
static String user;
final static int MAX_STRING=20;

public static void main(String[] args)throws StringTooLongException1
{
	//Import Scanner Object named scan into main method body
Scanner scan= new Scanner(System.in);
try{
	System.out.println("Enter a word. Enter Done to exit program");
	//This sets the String user to the Scanner passing nextLine
	user=scan.nextLine();
	//passes user through equals method.IgnoreCase ignores camelCasing/lettering.
	if(user.equalsIgnoreCase("Done"))
	//The Program exists this if statement after prompt. Return reserved method does
	//not have to have an associated variable. The return is used as a substitute instead of else.
	return;
	//Setting user variable to the length method.
	//Calls a new object of the StringTooLong method.If the length is greater than MAX_STRING
	if(user.length()>MAX_STRING)
	//This is the constructor of StringTooLongException1 file
	throw new StringTooLongException1("PrintStackMessageGoesHere");
	//This displays if an input has been received
	System.out.println("Character Length OK");
	user=scan.nextLine();
}
//This will execute if the following above fails.
catch(StringTooLongException1 e)
{
	//Refers to the e in the catch. Passes getMesssage method.
	System.out.println(e.getMessage());
	user=scan.nextLine();
}
}
}