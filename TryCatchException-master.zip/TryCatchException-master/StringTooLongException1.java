//This class refers to the Exception class from the Java Library
public class StringTooLongException1 extends Exception
{
StringTooLongException1(String message)
{
super(message);
}
}