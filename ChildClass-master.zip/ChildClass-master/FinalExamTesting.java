//April McBroom
//9-30-18
import java.util.Scanner;

public class FinalExamTesting
{
public static void main(String[] args)
{
//Local variables inside the main method body. Passed through the FinalExam constructor below.
//Local variables do not keep their global settings, meaning, their data can be changed/lost.
int questions;
int missed;

Scanner keyboard= new Scanner(System.in);

System.out.print("How many questions are on the final exam? ");
questions=keyboard.nextInt();

System.out.print("How many questions did the student miss? ");
missed=keyboard.nextInt();

//This lines calls back the constructor located in FinalExam script with questions and missed. exam is the variable name for this script.
FinalExam exam= new FinalExam(questions, missed);

//The Driver Class will print out the associated question within each class.
System.out.println("Each question counts " +exam.getPointsEach()+" points."); //References method
System.out.println("The exam score is " +exam.getScore()); //References method
System.out.println("The exam grade is " +exam.getGrade()); //References Method//A constructor will always be encased in the same parathensis.
}
}

