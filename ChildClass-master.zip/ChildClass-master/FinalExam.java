//April McBroom
//9-30-18
public class FinalExam extends GradeActivity
{
private int numQuestions;
private double pointsEach;
private int numMissed;
int numberPoints;

//The constructor of the Final Exam script
public FinalExam(int questions, int missed)
{
double numericScore;
numQuestions=questions;
numMissed=missed;

//Arithmetic line
pointsEach=100.0/numQuestions;
numberPoints=numQuestions-numMissed;
numericScore=numberPoints*pointsEach;

setScore(numericScore);
}
public double getPointsEach()
{
return pointsEach;
}
public int getNumMissed()
{
return numMissed;
}
}