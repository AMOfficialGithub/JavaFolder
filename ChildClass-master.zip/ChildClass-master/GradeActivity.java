//April McBroom
//9-30-18
//Grade Activity

public class GradeActivity
{
//This script is the base-class as it contains the general attributes that will be usuable in the child/subclass class.
//Private variable
private double score;

public void setScore(double s)
{
score=s;
}

public double getScore()
{
return score;
}

public char getGrade()
{
char letterGrade;
if(score>=90)
{
letterGrade='A';//Only Acceptable Grade.
}
else if(score>=80)
{
letterGrade='B';
}
else if(score>=70)
{
letterGrade='C';
}
else if(score>=60)
{
letterGrade='D';
}
else
{
letterGrade='F';
}
return letterGrade;
}
}
