//April McBroom
//9-26-18
//Main Method/Driver Class
import java.util.Scanner;

public class L2_ALM
{
public static void main(String[] args)
{
//Local variables inside the main method body.Non-Global.
	int questions;
	int missed;

	//Setting variables values to be used by subclass.
	double grammarscore=30;
	double spellingscore=20;
	double lengthscore=20;
	double contentscore=30;

	Scanner output= new Scanner(System.in);

	System.out.print("How many Essay questions are in the course?");
	questions=output.nextInt();
	output.nextLine();
	System.out.print("How many Essay questions did the student miss?");
	missed=output.nextInt();

//This lines calls back the class in GradeActivity Object Class and Essay Object subclass.
	Essay_ALM details= new Essay_ALM(questions, missed, grammarscore, spellingscore, lengthscore, contentscore);

	System.out.println("Each question counts "+details.getPointsEach()+"points."); //refers to PointEach in Essay Class
	System.out.println("The Grammar score: "+details.getGScore()); //Methods from Essay Class Object below
	System.out.println("The Spelling Score: "+details.getSGrade());
	System.out.println("The Correct Length Score: "+details.getCLength());
	System.out.println("The Content Score: "+details.getCScore());
	System.out.println("The exam score is: " +details.getScore()); //Inherited method getScore
	System.out.println("The exam grade is: " +details.getGrade()); //Inherited method getGrade
}
}

