//April McBroom
//9-26-18
//subclass
public class Essay_ALM extends GradeActivity
{
	private int numQuestions; //Question 1
	private int numMissed;
	private double pointsEach;//Points allocated for each mini scores

	double grammarscore;
	double spellingscore;
	double lengthscore;
	double contentscore;
	int numberPoints;

public Essay_ALM(int questions, int missed, double grammarscore, double spellingscore, double lengthscore, double contentscore)
{
	double numericScore; //Total numerical version of score

	numQuestions=questions;
	numMissed=missed;
	pointsEach=100.0/numQuestions; //Math for number of points
	numberPoints = numQuestions-numMissed; //Math for total earned points
	numericScore=numberPoints*pointsEach; //Math for whole grade

    //Math values for other scores
	this.grammarscore=numericScore*0.30;
	this.spellingscore=numericScore*0.20;
	this.lengthscore=numericScore*0.20;
	this.contentscore=numericScore*0.30;

    //Sets the numericScore value
	setScore(numericScore);
}

public double getPointsEach() //returns value for pointsEach
{
	return pointsEach;
}

public int getNumMissed() //returns value for numMissed
{
	return numMissed;
}

public double getGScore() //grammarscore
{
	return grammarscore;
}

public double getSGrade() //Spellingscore
{
	return spellingscore;
}

public double getCLength()//LengthScore
{
return lengthscore;
}
public double getCScore() //ContentScore
{
return contentscore;
}
}




