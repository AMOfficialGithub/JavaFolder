
public class App {
    
    public static void main(String [] args){
        reduceByOne(10); //invoking method
        //invoking the method. Creating a new array. Starting from beginning to specific number in array
        System.out.println(recursiveLinearSearch(new int[] {4,48,34,76}, 0,76));
    }
    public static void reduceByOne(int n){
        //Base Case below in if condition
        if( n != 0){
        reduceByOne(n-1);
    }
        System.out.println("Completed Call: "+ n); //BackTracing
}
    public static int recursiveLinearSearch(int [] a, int i, int x){
        //if evaluated true, x was not found in the array
        if( i > a.length-1){
            return -1;
        }
        else if(a[i] == x){
            return i;
        }else{
            System.out.println("index at: "+ i);
            return recursiveLinearSearch(a, i+1, x);
        }
    }
}
