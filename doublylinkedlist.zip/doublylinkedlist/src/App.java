
public class App {
    public static void main(String [] args)
    {
       doublylinkedlist thelist = new doublylinkedlist();
       thelist.insertfirst(22);
       thelist.insertfirst(33);
       thelist.insertfirst(45);
       thelist.insertfirst(599);
       thelist.insertfirst(277);
       thelist.insertLast(67);
       thelist.insertLast(328);
       thelist.displayForward();
       thelist.displayBackward();
       thelist.deleteFirst();
       thelist.deleteLast();
       thelist.deleteKey(45);
       thelist.displayForward();
       thelist.insertAfter(23, 77);
       thelist.insertAfter(34, 88);
       thelist.displayForward();
               
               
    }
}
