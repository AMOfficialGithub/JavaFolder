public class Node {
    public int data;
    public Node next, previous;
    
    public void displayNode(){
        System.out.print("{"+data+" }");
    }
}
