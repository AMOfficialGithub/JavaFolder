public class doublylinkedlist {
    private Node first, last;
    
    public doublylinkedlist(){
        this.first = null;
        this.last = null;
    }
    public boolean isEmpty(){
        return first == null;
        
    }
    public void insertfirst(int data)
    {
        Node newNode = new Node();
        newNode.data = data;
        
        if(isEmpty())
        {
            last= newNode; //if empty, last will refer to the new node
    }
        else
        {
            first.previous = newNode;
        }
        newNode.next = first; //new new next will point to old first
        this.first = newNode;
    }
    public void insertLast(int data){
        Node newNode = new Node();
        newNode.data = data;
        
        if(isEmpty())
        {
            first = newNode;
        }
        else
        {
           last.next = newNode; //assigning old last to new node
            newNode.previous = last; //THE OLD LAST WILL BE NEWNODES previous
        }
        last = newNode; // last field point to the new node
    }
    //assume non-empty list
    public Node deleteFirst()
    {
        Node temp = first;
        if(first.next == null) //only one item in list
        {
            last = null;
        }
        else{
            first.next.previous = null; //first node point to null
        }
        first = first.next;//assigning reference of node following the old first node to first field in linked list
        return temp; //return deleted old first node
    }
    //assum non-empty list
    public Node deleteLast()
    {
        Node temp = last;
        if(first.next == null){
            first = null;
        }else
            {
                 last.previous.next = null;
                    }
        last = last.previous;
        return temp;
    }
    //assume non-empty list
    public boolean insertAfter(int key, int data){
        Node current = first; //start from list beginnig
        while(current.data != key)
        {
            current = current.next;
            if(current == null){
                return false;
            }
        }
        Node newNode = new Node();
        newNode.data = data;
        if(current == last){
            current.next = null;
            last = newNode;
        }
        else{
            newNode.next = current.next; //new node next field should point to the node ahead of the current node
            current.next.previous = newNode; //the node ahead of current, previous field should point to new node
        }
        newNode.previous = current;
        current.next = newNode;
        return true;
}
    //assum non-empty list
    public Node deleteKey(int key){
        Node current = first; //start from beginning
        while(current.data != key){
            current = current.next;
            if(current == null){
                return null;
            }
        }
        if(current == first)
        {
            first = current.next; //make the first field point to the node following current
        
        }
        else
        {
            current.previous.next = current.next;
        }
        if(current == last){
            last = current.previous;
        }
        else
        {
            current.next.previous = current.previous;
            
        }
        return current;
    }
    public void displayForward(){
        System.out.print("List (first -->last)");
        Node current = first;
        while(current != null){
            current.displayNode();
            current = current.next;
        }
        System.out.println();
    }
    public void displayBackward(){
         System.out.print("List (last -->first)");
        Node current = first;
        while(current != null){
            current.displayNode();
            current = current.next;
        }
        System.out.println();
    }
}