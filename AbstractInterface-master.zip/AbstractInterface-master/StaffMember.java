		/*April McBroom
		10-8-18
		Class*/
		//Abstract Class Staff Member
abstract public class StaffMember implements Payable
{
		//Protected variables.
protected String name;
protected String address;
protected String phone;

		//Constructor
public StaffMember(String eName, String eAddress, String ePhone)
{
this.name=eName;
this.address=eAddress;
this.phone=ePhone;
}
	//Stringtype Return
public String toString()
{
String result="Name:"+name+"\n";

result+="Address:"+address+"\n";
result+="Phone:"+phone;
return result;
}

}
