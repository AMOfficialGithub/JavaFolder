	/*April McBroom
	10-8-18
	Driver Class*/
	//Firm Driver
public class Firm
{
	//Instance Area For Variables in Class Scope.
public static void main(String[] args)
{
	//Initalizing Class files
	Staff personnel= new Staff();
	personnel.payday();
}
}