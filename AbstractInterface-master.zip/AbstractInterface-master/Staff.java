		/*April McBroom
		10-8-18
		Parent Class*/
		//Staff Implements Payable Interface
public class Staff
{
private StaffMember[] staffList;
		//Constructor
public Staff()
{
staffList = new StaffMember[6];
		//5 values in Parameter
staffList[0]= new Executive(" Sam"," 123 Main Line "," 555-0469 "," 123-45-6789 ",2423.07);

staffList[1]= new Employee(" Carla"," 456 Off Line "," 555-0101 "," 987-65-4321 ",1246.15);

staffList[2]= new Employee(" Woody", " 789 Off Rocker ", " 555-0000 ", " 010-20-3040 ",1169.23);

staffList[3]= new Hourly(" Diana"," 678 Fifth Avenue "," 555-0690 "," 958-47-3625 ",10.55);
	//3 values in Parameter
staffList[4]= new Volunteer(" Norm"," 987 Suds Blvd. "," 555-7282 ");

staffList[5]= new Volunteer(" Cliff"," 321 Duds Lane "," 555-7282 ");

		//Calls Executive Object with staffList arrary. Calls awardBonus method and passes $500.00
((Executive)staffList[0]).awardBonus(500.00);

		//Calls Hourly class with staffList Array. Adds 40 hours.
((Hourly)staffList[3]).addHours(40);
}
		//payday amount.
public void payday()
{
		//Reference Variable
	double amount;
		//Count initiated at 0. If Count is less than the total elements of list, Print out count.
		//Add 1 to count.
	for(int count=0; count<staffList.length; count++)
	{
		//Prints out staffList arrary
		System.out.println(staffList[count]);
		//Print out count and pay() method.
		amount= staffList[count].pay();//Polymorphic Method.
		//If amount is 0.0, print out Thanks. Otherwise print out paid amount.
	if(amount==0.0)
	System.out.println("Thanks!");
	else
	System.out.println("Paid:"+amount);
	System.out.println("--------------------------------");
	}
}
}



