		/*April McBroom
		10-8-18
		Class*/
		//Child/Subclass File
public class Volunteer extends StaffMember
{
		//3 argument Constructor
public Volunteer(String eName, String eAddress, String ePhone)
{
			//Refers to StaffMember Constructor. 3 Arguments.
			super(eName,eAddress,ePhone);
}
public double pay()
{			//Volunteer Pay Method.
			return 0.0;
}
}