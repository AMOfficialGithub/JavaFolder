	/*April McBroom
	10-8-18
	Child Class*/
public class Hourly extends Employee
{
	private int hoursWorked;
		//Constructor for Hourly
	public Hourly(String eName, String eAddress, String ePhone, String socSecNumber, double rate)
	{
		//Constructor of Employee
		super(eName, eAddress, ePhone, socSecNumber, rate);
		hoursWorked=0;
	}
	public void addHours(int moreHours)
	{//hoursWorked is added to moreHours. Stored in hoursWorked.
		hoursWorked+=moreHours;
	}
	public double pay()
	{
		//Arithmetic
			double payment= payRate*hoursWorked;
			//Starting hours
			hoursWorked=0;
			return payment;
	}
	public String toString()
	{
		//Refers to parentclass toString
		String result= super.toString();
		//result and hoursWorked are added together. Stored in result.
		result+="\nCurrent hours:"+hoursWorked;
		return result;
	}
}
