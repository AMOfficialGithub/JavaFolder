/*April McBroom
10-8-18
Class*/
//Interface Class
//Interface classes, similar to abstract, do not contain any data values in their methods.
public interface Payable
{
public double pay();
}