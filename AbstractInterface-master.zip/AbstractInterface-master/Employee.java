	/*April McBroom
		10-8-18
		Child Class*/
public class Employee extends StaffMember
{
	protected String socialSecurityNumber;
	protected double payRate;

	public Employee(String eName, String eAddress, String ePhone, String socSecNumber, double rate)
	{
		//Referencing Parent Class StaffMember. No Identifiers Needed.
		super(eName, eAddress, ePhone);

		this.socialSecurityNumber=socSecNumber;
		this.payRate=rate;
	}
	public String toString()
	{
		//Refers to SuperClass StaffMember toString Method
		String result= super.toString();
		result+="\nSocial Security Number:"+socialSecurityNumber;

		return result;
	}
		public double pay()
		{
			return payRate;
		}
		}

