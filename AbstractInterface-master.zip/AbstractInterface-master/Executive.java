	/*April McBroom
		10-8-18
		Child Class*/
public class Executive extends Employee
{
	private double bonus;

	public Executive(String eName, String eAddress, String ePhone, String socSecNumber, double rate)
	{
		super(eName, eAddress, ePhone, socSecNumber, rate);
		this.bonus=bonus=0;
	}
	public void awardBonus(double execBonus)
	{
		//execBonus set to global variable bonus
		bonus= execBonus;
	}
	public double pay()
	{
		double payment= super.pay()+bonus;
		bonus=0;
		return payment;
	}
}

