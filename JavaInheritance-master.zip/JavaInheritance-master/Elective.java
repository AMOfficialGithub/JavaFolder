//April McBroom
//9-25-19
//Child class Golf
public class Elective extends Course
{
String elective="Elective Course:"; //variable to be displayed at top

public Elective(String title1,String number1,String description1,String department1)
{
//Course base/parent class.
super(title1,number1,description1,department1);
}

public String toString()
{
String result = elective + "\n";
result += super.toString();
return result;
}
}