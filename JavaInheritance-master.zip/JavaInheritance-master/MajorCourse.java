//April McBroom
//9-25-18
//Child Class Math
public class MajorCourse extends Course
{
	//Variables for MajorCourse class
	String major;
	String prereq;
    //Constructor
	public MajorCourse(String title1, String number1, String description1, String department1, String major1, String prereq1)
	{
		super(title1, number1, description1, department1); //the super constructor must always be 1st in child class.

		major=major1; //Assigned variables
		prereq=prereq1;
	}

	public String toString()
	{
		//Initalizing result set to super toString method. 
		String result=super.toString();

		result+="Major: "+major+"\n";
		result+="Pre/Co-Requisites(s): "+prereq;

		return result;
	}
}