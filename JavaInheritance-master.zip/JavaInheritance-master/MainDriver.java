//April McBroom
//9-25-18
//Driver Class
public class MainDriver
{

	public static void main(String[] args)
	{
		System.out.println("Course Major: Computer Science");
		System.out.println("Pre/Co-Requisite(s):none\n");

        //Initiating Class Objects with call toString();
        //The driver class of the initiated files is based on the # inside the parameters of the constructor class.
		MajorCourse math = new MajorCourse("Discret Mathematics","CSC215", "Instruction on the mathematical modeling of real-world problems using discret math concepts.", "Computer Science", "Computer Science", "CSC101");
		GeneralEducation art = new GeneralEducation("Basic Art", "ART101", "Instruction on concepts in art. Lecture and studio time required.", "Art", "Fine Arts");
        Course spanish = new Course("Spanish for Beginners 1","SPA101","Introduction to Spanish Language. Course focuses on concepts on the language and speaking excersises.","Modern Languages");
        Elective golf = new Elective("Golf","REC2010","Introduction to the game of golf, including rules of play and basic techniques. Course consists of instructional class time as well as weekly rounds of play.","Physical Education");
		System.out.println(math.toString() + "\n\n" + art.toString()+"\n\n" +spanish.toString() + "\n"+ golf.toString());
	}
}