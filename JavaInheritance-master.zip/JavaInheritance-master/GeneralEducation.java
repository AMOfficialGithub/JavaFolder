//April McBroom
//9-25-18
//Child Class Art
public class GeneralEducation extends Course
{
	//Variable to be assigned.
     String gened;

public GeneralEducation(String title1,String number1, String description1, String department1, String gened) //variables for constructor.
{
	//Importing the super reference constructor of the parent class
	super(title1,number1,description1,department1); //Referencing base-class Course with arguements.
	this.gened = gened;
}

	//GeneralEducation's toString method
	public String toString()
	{
		//Initalizes and sets result to the parent-class constructor. Calls toString method.
		String result=super.toString();
		result+="General Education Requirement: "+gened;
		return result;
	}
}