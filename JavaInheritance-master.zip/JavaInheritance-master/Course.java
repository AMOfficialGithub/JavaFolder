//April McBroom
//9-25-19
//Super Class/ParentClass/Base Class
public class Course
{
	String title;
	String number;
	String description;
	String department;

	public Course(String title1,String number1,String description1,String department1)
	{
		this.title= title1;
		this.number=number1;
		this.description=description1;
		this.department=department1;
	}
     //toString method
	public String toString()
	{
		String result="";

		result+="Course Title: "+title+"\n"; //concating with the String Object
		result+="Course Number: "+number+"\n";
		result+="Course Description: "+description+"\n";
		result+="Department: "+department+"\n";

		return result;
	}
}