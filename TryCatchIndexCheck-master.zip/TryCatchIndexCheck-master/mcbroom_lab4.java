//April McBroom
//10-24-18
//Exception Handling:LAB4:Try Catch with IndexOutOfBounds
import java.util.Scanner;

public class mcbroom_lab4
{
	public static void main(String[] args)
	{
		//Variables to be used
		String fullname;
		//Contains integer types for the beginning name, ending name,and realBegin
		int realBegin, begin, end;
		String lastname;
		//Loop set to true at default
		boolean loop = true;

		Scanner scan= new Scanner(System.in);

		System.out.println("Enter your full name:  ");
		fullname=scan.nextLine();
		//This sets the split method to split at blank space for entire name. New Method.
		String[]splitme=fullname.split(" ");
		System.out.println(fullname);
		//Referencing last-name variable Running splitme array. Passing splitme array minus -1 for index.
		lastname = splitme[splitme.length - 1];
		//Stores into realbegin. //Compares the fullname index by the index of the lastname.
		realBegin = fullname.indexOf(lastname);

			//The while loop takes in both the index for begin, and for end.
		while(loop){
			System.out.println("Enter the beginning and ending index number of your lastname: ");
			begin = scan.nextInt();
			end = scan.nextInt();
		//Try Catch Method. If begin is greater than the index of fullname variable, throw IndexOutOfBoundsException.
		//Else If Loop. If the end index is smaller than the index of the end variable, throow IndexOutOfBoundsException.
			try{
				if(begin > fullname.length() - 1){
					throw new IndexOutOfBoundsException("Not correct number for extracting your last name. " + begin);
				}
				else if(end > fullname.length() - 1){
					throw new IndexOutOfBoundsException("Not correct number for extracting. String index out of range: " + end);
				}
				//Substring index must have +1 added. This line compares the substring actual data to the lastname data, not Pointer Object.
				//Setting loop to false. Prevents continous looping.
				else if(fullname.substring(begin,end+1).equals(lastname)){
					System.out.println("Last Name: "+lastname);
					loop = false;
				}
				else{
					System.out.println("Incorrect input. Please try again ");
					scan.nextLine();
				}
			}
			//Catch Line Method. Prints out the associated getMessage(); default with Throw-Exception Classes.
			//Setting loop to false.
			catch(IndexOutOfBoundsException e){
				System.out.println(e.getMessage());
				loop = false;
			}
		}
	}
}




